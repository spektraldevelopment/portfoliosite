var enc = new Array();
enc[0] = Array(":","1","2","3","4","5","6","7","8","9","0", ".");
enc[1] = Array("t","i","e","g","q","z","y","p","l","b","c", "a");
enc[2] = Array("d","q","c","t","f","g","y","k","p","a","w", "s");
enc[3] = Array("q","w","s","d","c","v","b","t","y","u","f", "g");
enc[4] = Array("z","x","a","s","q","w","h","j","v","n","b", "c");
enc[5] = Array("t","c","b","q","w","j","l","p","r","a","y", "n");

function lock(str){
	str = str.split("");
	key = Math.floor(Math.random()*5) + 1;
	var x;
	var locked = new Array();
	for (y=0; y<=str.length - 1; y++){
		for (x=0; x<=11; x++){
			if (str[y] == enc[0][x]){
				locked[y] = str[y].replace(enc[0][x], enc[key][x]);
			}
		}
	}
	locked.push(key);
	var str_locked = "";
	for (l=0; l<=locked.length - 1; l++){
		str_locked = str_locked + locked[l];
	}
	return str_locked;
}


function unlock(str){
	key = str.substring(str.length - 1, str.length);

	str = str.substr(0, str.length - 1);

	str = str.split("");

	var x;
	var unlocked = new Array();
	for (y=0; y<=str.length - 1; y++){
		for (x=0; x<=11; x++){
			if (str[y] == enc[key][x]){
				unlocked[y] = str[y].replace(enc[key][x], enc[0][x]);
			}
		}
	}
	var str_unlocked = "";
	for (l=0; l<=unlocked.length - 1; l++){
		str_unlocked = str_unlocked + unlocked[l];
	}
	return str_unlocked;
}
